Hi!

Here are the source files for building the AVR PC keyboard decoder.
The ASCII codes presented are listed in the source file named "PCkybrd.asm"

These were assembled using AVR studio 4 from Atmel.  The Intel-Hex object 
file is included as well as the ExpressPBC schematic file.

Thanks!

Daryl Rictor

*** Use these files at your own risk.  No warrantee is provided. (c)2004

